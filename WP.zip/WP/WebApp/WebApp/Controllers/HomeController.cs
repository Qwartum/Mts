﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;


namespace WebApp.Controllers
{
    public class HomeController : Controller
    {

        public ActionResult Index()
        {
            Entities db = new Entities();
            SelectList cat = new SelectList(db.Categories, "CategoriesID", "Name");
            ViewBag.Categ = cat;
            return View(db.Offers);
        }
        [HttpPost]
        public ActionResult Index(int CategoriesID)
        {
       
            Entities db = new Entities();
            var Ofr = db.Offers.Where(a => a.CategoriesID == CategoriesID);
            return View(Ofr);
        }
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}